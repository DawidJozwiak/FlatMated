//
//  MainViewController.swift
//  FlatmateSeeker
//
//  Created by Dawid Jóźwiak on 25/10/2021.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

}
